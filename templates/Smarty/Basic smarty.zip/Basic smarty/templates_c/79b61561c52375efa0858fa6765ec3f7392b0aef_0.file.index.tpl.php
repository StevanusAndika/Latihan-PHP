<?php
/* Smarty version 3.1.48, created on 2023-05-01 03:02:23
  from '/storage/emulated/0/htdocs/Latihan smarty/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_644f2bbf81c278_28605097',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '79b61561c52375efa0858fa6765ec3f7392b0aef' => 
    array (
      0 => '/storage/emulated/0/htdocs/Latihan smarty/index.tpl',
      1 => 1682910130,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_644f2bbf81c278_28605097 (Smarty_Internal_Template $_smarty_tpl) {
?>
Hai <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
<br></br>
Selamat datang di latihan smarty!<?php }
}
