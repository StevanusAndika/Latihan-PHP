<?php
/* Smarty version 3.1.48, created on 2023-05-01 04:22:28
  from '/storage/emulated/0/htdocs/Latihan smarty/coba.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_644f3e84e6ee70_26199157',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c2ae8db085a8a7eb643a0c5a41e09d6479f9bf8b' => 
    array (
      0 => '/storage/emulated/0/htdocs/Latihan smarty/coba.tpl',
      1 => 1682914936,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_644f3e84e6ee70_26199157 (Smarty_Internal_Template $_smarty_tpl) {
$__section_customer_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['custid']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_customer_0_total = $__section_customer_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_customer'] = new Smarty_Variable(array());
if ($__section_customer_0_total !== 0) {
for ($__section_customer_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_customer']->value['index'] = 0; $__section_customer_0_iteration <= $__section_customer_0_total; $__section_customer_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_customer']->value['index']++){
?>
 Nama :<?php echo $_smarty_tpl->tpl_vars['custid']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_customer']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_customer']->value['index'] : null)]['nama'];?>
<br/>
 Kelas:<?php echo $_smarty_tpl->tpl_vars['custid']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_customer']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_customer']->value['index'] : null)]['kelas'];?>
<br/><br/>
 <?php
}
}
?>
 <hr/><?php }
}
