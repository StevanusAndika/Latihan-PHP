<?php
include "header.php";
$page  = "coba_foreach";

$data = array("nama"=>"stev","Kelas"=>"12mm2");
$smarty->assign('custid',$data);

include "footer.php";
?>
