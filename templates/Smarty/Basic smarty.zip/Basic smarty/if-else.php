{if kondisi}
.....
{else}
{/if}
{*bentuk percabangan if  *}

{if kondisi}
......
{else if}
....
{else}
{/if}