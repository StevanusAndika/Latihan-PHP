<?php
//panggil file .tpl yg ingin ditampilkan
$smarty->display ($page.".tpl");

?>