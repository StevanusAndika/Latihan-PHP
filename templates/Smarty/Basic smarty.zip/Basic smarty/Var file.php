$smarty->asssign('first_name','Stevanus');
$smarty->asssign('middle_name','Andika Galih');
$smarty->asssign('first_name','Setiawan');
