<?php
//include file header.php yg memiliki setinggan smarty 
include "header.php";
$page = "index";
$name = "Stevanus";

//kirim data variabel ke file .tpl
$smarty ->assign('name',$name);

//panggil template footer
include "footer.php"
?>