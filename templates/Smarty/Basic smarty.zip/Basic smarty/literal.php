{*literal digunakan oleh smarty untuk menandakan bahwa ada inline script cas atau javascript. Contohnya seperti berikut:*}

<script language="javascript"type="text/javascript">
{literal}
function myJsFunction(name){
  alert("Hi\n"+name);
}
{/literal}
  
</script>
<a href="javascript:myJsFunction('Stevanus')">klik disini</a>