<?php
//instalasi smarty
require 'libs/Smarty.class.php';
$smarty = new Smarty;
$smarty -> caching =false;
/*$smarty->caching false artinya tidak mengaktifkan caching pada smarty. Jika Anda ubah menjadi TRUE, maka caching digunakan untuk mempercepat pemanggilan display() atau fetch() dengan menyimpan outputnya ke dalam sebuah file. Jika versi cached tersedia maka akan menampilkan cache bersangkutan dan tidak akan membuat ulang output. Untuk halaman yang jarang sekali mengalami perubahan konten, ini baik digunakan untuk mempercepat performa web, tapi jika tidak, sebaiknya Anda atur FALSE.
   */
$smarty-> cache_lifetime=120;
//masa hidup cache adalah 120 detik

?>