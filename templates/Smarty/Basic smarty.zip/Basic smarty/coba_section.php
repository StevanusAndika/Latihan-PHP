<?php

include "header.php";
$page ="coba_section";
$data =array(100,102,104);
$smarty->assign('custid',$data);
include "footer.php";

/*
Perulangan yang hanya bisa disertai dengan array index misalnya seperti contoh pada file coba section.php. (section) tidak mendukung pengulangan secara langsung array assosiatif. Jika ingin menggunakan array assosiatif, harus disertai lebih dengan array index.
*/
?>