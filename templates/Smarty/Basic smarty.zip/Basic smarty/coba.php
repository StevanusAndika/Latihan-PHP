<?php
include "header.php";
$page  = "coba";

$data[0] = array("nama"=>"Stevanus Andika Galih Setiawan","kelas"=>"12mm2");
$data[1] = array("nama"=>"john gudel","kelas"=>"1B");
$data[2] = array("nama"=>"Rafi","kelas"=>"2B");

$smarty->assign('custid',$data);

include "footer.php";
?>