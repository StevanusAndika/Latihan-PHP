<?php /* Smarty version 3.1.48, created on 2023-05-01 02:29:21
         compiled from '/storage/emulated/0/htdocs/Latihan smarty/demo/configs/test.conf' */ ?>
<?php
/* Smarty version 3.1.48, created on 2023-05-01 02:29:21
  from '/storage/emulated/0/htdocs/Latihan smarty/demo/configs/test.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_644f2401ca0a21_78402384',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '004d8fa9b7e57ca4acbebe5f200057ce28af9c54' => 
    array (
      0 => '/storage/emulated/0/htdocs/Latihan smarty/demo/configs/test.conf',
      1 => 1680032754,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_644f2401ca0a21_78402384 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'Welcome to Smarty!',
    'cutoff_size' => 40,
  ),
));
}
}
