<?php
/* Smarty version 3.1.48, created on 2023-05-01 02:29:21
  from '/storage/emulated/0/htdocs/Latihan smarty/demo/templates/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_644f2401cbd596_24244063',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    'bc50ed7f0dd99b17c8e376eb9bb8b92b94420c45' => 
    array (
      0 => '/storage/emulated/0/htdocs/Latihan smarty/demo/templates/header.tpl',
      1 => 1680032754,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_644f2401cbd596_24244063 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '187388842644f2401cad046_35688003';
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:187388842644f2401cad046_35688003%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:187388842644f2401cad046_35688003%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
