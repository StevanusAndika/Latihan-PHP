<?php
/* Smarty version 3.1.48, created on 2023-05-01 02:29:21
  from '/storage/emulated/0/htdocs/Latihan smarty/demo/templates/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_644f2401d07487_40051489',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'af430744e381c998f11d71a2ac23f30e2e3660bb' => 
    array (
      0 => '/storage/emulated/0/htdocs/Latihan smarty/demo/templates/footer.tpl',
      1 => 1680032754,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_644f2401d07487_40051489 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '458696806644f2401cff621_07860137';
?>
</BODY>
</HTML>
<?php }
}
