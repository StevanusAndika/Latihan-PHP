{include file="header.tpl"}

{*sisipkan variabel dalam file*}
{include file="header.tpl"title="Latihan smarty"}
{*deklarasi var di header tpl*}
{$title}