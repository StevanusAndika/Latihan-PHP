setting codeigniter 3

1.buka folder application/config/config.php
2.setting base url

$config['base_url'] = 'http://localhost/nama_folder';
karena nama foldernya ci-basic ubah url menjadi $config['base_url'] = 'http://localhost/ci-basic';atau
http://127.0.0.1:8080/ci-basic(for linux)

3.untuk atur database buka application/config/database.php

isi :
$db['default'] = array(
	'dsn'	=> '',
	'hostname' => 'localhost',
	'username' => 'root',
	'password' => 'root',
	'database' => 'nama_db',
	'dbdriver' => 'mysqli',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => TRUE,
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);
4.buat controller dengan nama Stevanus.php(usahakan nama file dan class menggunakan huruf besar)
letak folder controllers(application/controllers)

buat file views di folder application/views

5.ubah controller pertama yg akan ditampilkan,pergi ke folder application/config/routes.php ubah defsult controller dari welcome menjadi stevanus

6.buat file . htaccess yg  sejajar dengan folder application
RewriteEngine On

# Menyembunyikan ekstensi .php
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_FILENAME}.php -f
RewriteRule ^(.*)$ $1.php [L]

# Mengarahkan seluruh traffic ke HTTPS
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Mengarahkan seluruh traffic ke www (Opsional)
RewriteCond %{HTTP_HOST} !^www\. [NC]
RewriteRule ^(.*)$ https://www.%{HTTP_HOST}%{REQUEST_URI} [L,R=301]



7.hilangkan $config['index_page'] = 'index.php' yg ada di folder application/config menjadi
$config['index_page'] = ' ';

pemanggilan url :
http://127.0.0.1:8080/ci-basic/index.php/stevanus/myfirstpage

penjelasan pemanggilan url codeigniter : bisa
Pemanggilan URL CodeIgniter di atas terdiri dari beberapa komponen:

1. `http://127.0.0.1:8080` adalah alamat atau URL dari server web yang digunakan untuk mengakses aplikasi CodeIgniter. Angka `127.0.0.1` adalah alamat localhost, yang berarti server web berjalan di komputer yang sama dengan browser yang digunakan. Angka `8080` adalah nomor port yang digunakan oleh server web untuk menerima permintaan HTTP.

2. `/ci-basic` adalah direktori atau folder tempat aplikasi CodeIgniter disimpan di server web.

3. `/index.php` adalah file utama yang dipanggil oleh CodeIgniter untuk memproses permintaan HTTP. File ini terletak di direktori root aplikasi.

4. `/stevanus/myfirstpage` adalah URI atau Uniform Resource Identifier yang menentukan halaman atau metode mana yang harus dipanggil oleh CodeIgniter. URI ini terdiri dari dua segmen: `stevanus`, yang menunjukkan nama controller yang akan dipanggil, dan `myfirstpage`, yang menunjukkan nama metode yang akan dipanggil di dalam controller tersebut.

Dalam rangkaian pemanggilan URL tersebut, CodeIgniter akan mengarahkan permintaan HTTP ke file `index.php` di direktori root aplikasi. Kemudian, CodeIgniter akan mencocokkan URI dengan controller dan metode yang sesuai, dalam hal ini `stevanus` dan `myfirstpage`. Controller dan metode yang sesuai akan dipanggil untuk memproses permintaan HTTP dan menghasilkan output yang sesuai untuk ditampilkan di browser.