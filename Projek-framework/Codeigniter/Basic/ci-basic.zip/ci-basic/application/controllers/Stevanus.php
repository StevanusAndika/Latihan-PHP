<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stevanus extends CI_Controller {

public function myfirstpage(){
  //firstpage merupakan method untuk menaruh logika
  
  //memanggil file/template yg akan ditampilkan browser
  $this->load->view('myfirst');

}
}